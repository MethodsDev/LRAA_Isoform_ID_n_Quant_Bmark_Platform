Supplementary Table 1	Differential usage between cell clusters, DEXSeq on pseudo-replicates
LRAA version	v0.51.0 (reference-guided, cluster-guided isoform set)
Datasets	PBMC: Kinnex 10x 3' scRNA-seq, 14 clusters. FTD: frontal cortex Kinnex 10x 3' snRNA-seq, 14 clusters.
Levels	
  SplicePattern	splice pattern (isoforms with the same intron chain, EM-assigned counts summed); group = gene
  TSS	LRAA TSS site (read 5' ends within 25 nt); group = gene
  PolyA	LRAA PolyA site (read 3' ends within 25 nt); group = gene
Test	Each cluster's cells dealt at random into 3 pseudo-replicates, counts summed per feature. DEXSeq ~ sample + exon + cluster:exon vs ~ sample + exon over all clusters with >= 30 cells (features as exon bins, groups as genes); gene q from perGeneQValue; stageR confirms the features carrying the change. Features tested if >= 10% of the group's counts in some cluster with >= 20 group counts there, and >= 10 counts overall; groups need >= 2 features.
Significant gene	q < 0.05 in at least 4 of 5 random dealings (seeds)
Event (one row)	significant gene x cluster pair, pairwise test on the pair's pseudo-replicates with the all-cluster dispersions: a feature at adjusted P < 0.05, |delta usage| >= 0.2, and >= 20 group counts in each cluster. Oriented so the largest significant change is a gain in cluster_B.
High confidence	reciprocal switch class, >= 5 unique FSM reads for both features, no flags.
Flags	monoexonic (site only on single-exon isoforms); close_sites (< 30 bp apart); A_rich_downstream (>= 12 A's in the 20 bases past a PolyA site); polyA_site_unsupported (no PAS, no PolyASite 2.0 support, > 7 downstream A's: internal priming); downstream_TSS_no_FSM (gained TSS downstream of the lost one without full-length reads: 5' truncation)
Summary sheet	per dataset x level: genes tested, significant genes (q < 0.05 in >= 4 of 5 seeds), genes with events and events (significant genes x cluster pairs), high-confidence genes and events
FTD TSS	interpret with care: nuclear reads are often 5'-truncated. LRAA calls TSS sites only with the 5' cap signature, which removes most truncation sites, but switches to a downstream TSS in neurons remain over-represented (see the paper)
Caveat	Pseudo-replicates come from one sample: they measure cell-to-cell sampling noise, not donor variation, so P values are optimistic. Rank by abs_delta and the high-confidence filter.
Source	LRAA util/sc/site_usage/ (site_usage_dexseq.R, annotate_site_usage_events.py, annotate_feature_usage_events.py); built by __PaperFigs/supp_tables/make_dexseq_supp_table.py

All events, one file per dataset x level, high-confidence events first.
FTD_TSS: interpret with care: nuclear reads are often 5'-truncated. LRAA calls TSS sites only with the 5' cap signature, which removes most truncation sites, but switches to a downstream TSS in neurons remain over-represented (see the paper)

column	description
PolyA_differs	SplicePattern: the two patterns' main PolyA sites differ
TSS_differs	SplicePattern: the two patterns' main TSS differ
abs_delta	|delta usage| of the gained feature between the clusters (usage = share of the group's counts)
both_FSM	>= 5 unique FSM reads for both features
both_sites_FSM	>= 5 unique FSM reads at both sites (the most of any isoform carrying the site)
cluster_A	first cluster of the pair
cluster_B	second cluster; the gained feature's usage is higher in B than in A
event_type	site events: tandem_3UTR, intronic_PolyA, alt_last_exon (PolyA); tandem_TSS, alt_first_exon (TSS)
exon_count_differs	SplicePattern: the two patterns differ in exon count
flags	quality flags; any flag excludes the event from high confidence (see README)
gained_PAS	gained feature: polyadenylation signal hexamer upstream of the site
gained_downstream_A_of_20	gained feature: A's in the 20 genomic bases downstream of the site
gained_feature	the feature whose usage rises most significantly from A to B
gained_is_downstream	the gained site lies downstream of the lost one on the transcript strand
gained_log2FC	gained feature: log2 fold change of counts per million between the clusters (the switch_class basis)
gained_main_PolyA	gained feature: PolyA site of the feature's most expressed isoform
gained_main_TSS	gained feature: TSS site of the feature's most expressed isoform
gained_max_isoform_uniq_FSM	gained feature: most unique FSM reads of any isoform carrying the site
gained_monoexonic_only	gained feature: the site is carried only by single-exon isoforms
gained_n_isoforms	gained feature: LRAA isoforms carrying the feature
gained_n_merged	gained feature: LRAA sites merged into this one
gained_n_seeds_confirmed	gained feature: seeds in which stageR confirms the feature
gained_num_exons	gained feature: exon count
gained_padj	gained feature: pairwise adjusted P (Benjamini-Hochberg over all pairwise tests)
gained_pos	gained feature: site position
gained_reads_A	gained feature: counts in cluster A
gained_reads_B	gained feature: counts in cluster B
gained_site	the site whose usage rises most significantly from A to B
gained_site_evidence	gained feature: PAS hexamer, PolyASite 2.0 sample fraction, A's in the 20 genomic bases downstream
gained_site_supported	gained feature: PAS hexamer, or PolyASite 2.0 cluster used by >= 10% of samples, or <= 7 downstream A's
gained_source	gained feature: LRAA site catalog the site comes from
gained_transcript_ids	gained feature: LRAA isoforms making up the feature (site events: the gene's isoforms carrying the site)
gained_uniq_FSM	gained feature: unique full-length (FSM) reads of the feature's isoforms, summed over the cluster quantifications
gained_usage_A	gained feature: usage (share of the group's counts) in cluster A
gained_usage_B	gained feature: usage (share of the group's counts) in cluster B
gene_key	gene (symbol|chrom|strand)
gene_reads_A	read ends of the gene at tested sites in cluster A
gene_reads_B	read ends of the gene at tested sites in cluster B
gene_symbol	gene symbol
group_reads_A	counts of the group in cluster A (tested features)
group_reads_B	counts of the group in cluster B (tested features)
high_confidence	reciprocal switch, >= 5 unique FSM reads for both features, no flags
lost_PAS	lost feature: polyadenylation signal hexamer upstream of the site
lost_downstream_A_of_20	lost feature: A's in the 20 genomic bases downstream of the site
lost_feature	the feature whose usage falls most from A to B
lost_log2FC	lost feature: log2 fold change of counts per million between the clusters (the switch_class basis)
lost_main_PolyA	lost feature: PolyA site of the feature's most expressed isoform
lost_main_TSS	lost feature: TSS site of the feature's most expressed isoform
lost_max_isoform_uniq_FSM	lost feature: most unique FSM reads of any isoform carrying the site
lost_monoexonic_only	lost feature: the site is carried only by single-exon isoforms
lost_n_isoforms	lost feature: LRAA isoforms carrying the feature
lost_n_merged	lost feature: LRAA sites merged into this one
lost_n_seeds_confirmed	lost feature: seeds in which stageR confirms the feature
lost_num_exons	lost feature: exon count
lost_padj	lost feature: pairwise adjusted P (Benjamini-Hochberg over all pairwise tests)
lost_pos	lost feature: site position
lost_reads_A	lost feature: counts in cluster A
lost_reads_B	lost feature: counts in cluster B
lost_site	the site whose usage falls most from A to B
lost_site_evidence	lost feature: PAS hexamer, PolyASite 2.0 sample fraction, A's in the 20 genomic bases downstream
lost_site_supported	lost feature: PAS hexamer, or PolyASite 2.0 cluster used by >= 10% of samples, or <= 7 downstream A's
lost_source	lost feature: LRAA site catalog the site comes from
lost_transcript_ids	lost feature: LRAA isoforms making up the feature (site events: the gene's isoforms carrying the site)
lost_uniq_FSM	lost feature: unique full-length (FSM) reads of the feature's isoforms, summed over the cluster quantifications
lost_usage_A	lost feature: usage (share of the group's counts) in cluster A
lost_usage_B	lost feature: usage (share of the group's counts) in cluster B
median_q	median gene-level q (perGeneQValue) over the 5 seeds
n_features_sig	features of the group with a significant change in this pair
n_features_tested	features of the group tested
n_seeds_significant	of the 5 random dealings into pseudo-replicates, how many give gene q < 0.05
n_sites	sites of the gene tested
n_sites_sig	sites of the gene with a significant change in this pair
separation	distance between the gained and lost sites (bp)
splicing_class	site events, from the reads at the two sites: alt_terminal_usage (tandem: same terminal exon and splicing), alt_splicing:terminal_exon (alternative first / last exon, intronic PolyA, retained intron), alt_splicing:internal (an internal intron differs), unspliced_site, unresolved
switch_class	from the two features' counts per million (1.5-fold): reciprocal (gained up, lost down), concordant (both change the same way), one site changes, neither
